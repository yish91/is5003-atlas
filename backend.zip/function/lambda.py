import json
from summa.summarizer import summarize
import wikipedia
import nltk, string
from sklearn.feature_extraction.text import TfidfVectorizer


def lambda_handler(event, context):
    stemmer = nltk.stem.porter.PorterStemmer()
    remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)

    def stem_tokens(tokens):
        return [stemmer.stem(item) for item in tokens]

    def normalize(text):
        return stem_tokens(nltk.word_tokenize(text.lower().translate(remove_punctuation_map)))

    vectorizer = TfidfVectorizer(tokenizer=normalize, stop_words='english')

    def cosine_sim(text1, text2):
        tfidf = vectorizer.fit_transform([text1, text2])
        return ((tfidf * tfidf.T).A)[0, 1]

    def generate_result(closeness, network_text, editable):
        inputLength = len(editable.split())
        if inputLength > 50:
            allFeedback = {
                "isComplete": False,
                "jsonFeedback": { "editable": "Your input is " + str(inputLength) + " words long. Please try to keep it at or below 50 words!" },
                "htmlFeedback": "<div>Your input is " + str(inputLength) + " words long. Please try to keep it at or below 50 words!</div>",
                "textFeedback": "Your input is " + str(inputLength) + " words long. Please try to keep it at or below 50 words!"
            }
            return allFeedback

        network_text = network_text.replace(" ", "").replace("\n", "").lower()
        editable = editable.replace(" ", "").replace("\n", "").lower()
        if editable in network_text:
            allFeedback = {
                "isComplete": False,
                "jsonFeedback": { "editable": "Please do not copy and paste!" },
                "htmlFeedback": "<div>Please do not copy and paste!</div>",
                "textFeedback": "Please do not copy and paste!"
            }
            return allFeedback
        if closeness < 30:
            allFeedback = {
                "isComplete": False,
                "jsonFeedback": { "editable": "Your input is " + str(closeness) + "% matching. Please try to hit at least 30%!" },
                "htmlFeedback": "<div>Your input is " + str(closeness) + "% matching. Please try to hit at least 30%!</div>",
                "textFeedback": "Your input is " + str(closeness) + "% matching. Please try to hit at least 30%!"
            }
            return allFeedback
        else:
            allFeedback = {
                "isComplete": True,
                "jsonFeedback": { "editable": "Your input is " + str(closeness) + "% matching" },
                "htmlFeedback": "<div>Your input is " + str(closeness) + "% matching</div>",
                "textFeedback": "Your input is " + str(closeness) + "% matching"
            }
            return allFeedback

    searchQuery = ""
    inputText = ""
    method = event.get('httpMethod', {})
    if method == 'GET':
        queryStringParameters = event.get('queryStringParameters', {})
        if queryStringParameters and "chapter" in queryStringParameters and "input" in queryStringParameters:
            chapter = queryStringParameters["chapter"]
            inputText = queryStringParameters["input"]
            try:
                network_text = ""
                f = open("platform-revolution-summary/" + chapter +".txt", "r")
                for x in f:
                    network_text = network_text + " " + x
                f.close()
                summary = summarize(network_text, words=100)
                closeness = cosine_sim(summary, inputText) * 100
                allFeedback = generate_result(closeness, network_text, inputText)
                result = {
                    "isBase64Encoded": False,
                    "statusCode": 200,
                    "headers": {
                        'Access-Control-Allow-Origin' : '*',
                        'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Credentials' : 'true',
                        'Content-Type': 'application/json'
                    },
                    "body": json.dumps({
                        "isComplete": allFeedback["isComplete"],
                        "jsonFeedback": allFeedback["jsonFeedback"],
                        "htmlFeedback": allFeedback["htmlFeedback"],
                        "textFeedback": allFeedback["textFeedback"]
                    })
                }
                return result
            except Exception as e:
                result = {
                    "isBase64Encoded": False,
                    "statusCode": 404,
                    "headers": {
                        'Access-Control-Allow-Origin' : '*',
                        'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                        'Access-Control-Allow-Credentials' : 'true',
                        'Content-Type': 'application/json'
                    },
                    "body": str(e)
                }
                return result
        else:
            # result = {
            #     "isBase64Encoded": False,
            #     "statusCode": 404,
            #     "headers": {
            #         'Access-Control-Allow-Origin' : '*',
            #         'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            #         'Access-Control-Allow-Credentials' : 'true',
            #         'Content-Type': 'application/json'
            #     },
            #     "body": json.dumps({"error": "Please input search params"})
            # }
            # return result
            response = {}
            response["statusCode"]=302
            response["headers"]={'Location': 'https://yish91.github.io/is5003-atlas/'}
            data = {}
            response["body"]=json.dumps(data)
            return response
    if method == 'POST':
        postReq = json.loads(event.get('body', {})) 
        print(postReq)       
        editable = postReq["editable"]["0"].strip()
        editable = editable.split('"""')[1].replace("\n", " ")
        hidden =  postReq["hidden"]["0"].strip()
        shown = postReq["shown"]["0"].strip()
        userToken = postReq["userToken"]
        try:
            network_text = ""
            f = open("platform-revolution-summary/" + hidden +".txt", "r")
            for x in f:
                network_text = network_text + " " + x
            f.close()
            summary = summarize(network_text, words=100)
            closeness = cosine_sim(summary, editable) * 100
            allFeedback = generate_result(closeness, network_text, editable)
            result = {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {
                    'Access-Control-Allow-Origin' : '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS, DELETE',
                    'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Credentials' : 'true',
                    'Content-Type': 'application/json'
                },
                "body": json.dumps({
                    "isComplete": allFeedback["isComplete"],
                    "jsonFeedback": allFeedback["jsonFeedback"],
                    "htmlFeedback": allFeedback["htmlFeedback"],
                    "textFeedback": allFeedback["textFeedback"]
                })
            }
            return result
        except Exception as e:
            result = {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {
                    'Access-Control-Allow-Origin' : '*',
                    'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS, DELETE',
                    'Access-Control-Allow-Headers':'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Credentials' : 'true',
                    'Content-Type': 'application/json'
                },
                "body": str(e)
            }
            return result
    else:
        result = {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {
                'Access-Control-Allow-Origin' : '*',
                'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS, DELETE',
                'Access-Control-Allow-Headers':'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Credentials' : 'true',
                'Content-Type': 'application/json'
            },
            "body": json.dumps({"error": "Please use POST"})
        }
        return result
